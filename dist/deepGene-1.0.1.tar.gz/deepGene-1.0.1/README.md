## DEEPGene 
Design gene sequences to optimize expression using deep learning



1. python setup.py sdist
2. python setup.py bdist_wheel --universal

3. twine upload --repository-url https://test.pypi.org/legacy/ dist/*