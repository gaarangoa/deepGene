
def main():
    print 'here is the main'